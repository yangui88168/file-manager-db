import os
import sys
import asyncio
from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneCodeExpiredError

# ========================================================
# 🌟 每次只要修改下面这两个参数，直接运行即可稳定挂载 🌟
# ========================================================
API_ID = 33967470
API_HASH = "d5f8ba95419db3208c830c7d0fb7c303"  
# ========================================================

sys.stdout.reconfigure(line_buffering=True)

def get_existing_session():
    files = [f for f in os.listdir('.') if f.endswith('.session')]
    if not files: return None
    return files[0].replace('.session', '')

async def main():
    print("=" * 50)
    print("  Telegram 账号挂载常驻监听系统 (终极无缝接码版)")
    print("=" * 50)
    
    session_name = get_existing_session()
    
    # 自动盲猜并捕获本地可用代理端口
    working_proxy = None
    import socket
    for port in [10808, 10809, 7890, 7897]:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                working_proxy = {'proxy_type': 'socks5', 'addr': '127.0.0.1', 'port': port, 'rdns': True}
                break

    # 1. 优先读取老账号
    if session_name:
        print(f"-> 成功捕捉到本地现存容器: {session_name}.session")
        print("-> 正在启动直接免登安全网络握手...")
        client = TelegramClient(session_name, API_ID, API_HASH, proxy=working_proxy) if working_proxy else TelegramClient(session_name, API_ID, API_HASH)
    else:
        # 2. 如果是新接码的号，启动高容错接码护航机制
        print("[-] 提示：当前文件夹内没有现成的 .session 文件。")
        phone = input("请输入接码平台提供给你的手机号(带国家码，如 +855xxx): ").strip()
        if not phone: return
        
        session_name = f"session_{phone.replace(' ', '').replace('-', '').replace('+', '')}"
        client = TelegramClient(session_name, API_ID, API_HASH, proxy=working_proxy) if working_proxy else TelegramClient(session_name, API_ID, API_HASH)

    # 3. 拦截验证码的核心常驻监听模块
    @client.on(events.NewMessage(incoming=True))
    async def handler(event):
        if event.is_private:
            sender = await event.get_sender()
            if (sender and getattr(sender, 'verified', False)) or "telegram" in str(sender).lower():
                text = event.text or ""
                if "code" in text.lower() or "验证码" in text:
                    print("\n" + "*" * 40)
                    print(f"[重要提示] 挂载账号 [{session_name}] 拦截到最新登录验证码！")
                    print(text)
                    print("*" * 40 + "\n")

    try:
        await client.connect()
        
        # 如果未登录过，进行首次接码登录守护
        if not await client.is_user_authorized():
            print(f"-> 正在向 {phone} 请求发送官方验证码...")
            send_code_result = await client.send_code_request(phone)
            phone_code_hash = send_code_result.phone_code_hash
            
            print("\n[📢 核心指南] 请立刻去接码平台获取最新验证码！")
            print("[📢 核心指南] 注意：在控制台手动输入时，请用键盘慢速盲打，【千万不要复制粘贴】！")
            
            # 无限死循环：只要没超时，输错一万次也不会崩溃，会一直等待你把正确的数字打进去
            while True:
                try:
                    code = input("\n请输入接码平台刚刚刷新出来的 5 位纯数字验证码: ").strip()
                    if not code: continue
                    await client.sign_in(phone=phone, code=code, phone_code_hash=phone_code_hash)
                    break
                except PhoneCodeInvalidError:
                    print("[-] 错误：刚刚输入的验证码不对（可能不是最新的）。请去接码平台重新看，并手动输入！")
                except PhoneCodeExpiredError:
                    # 如果不幸遭遇平台极严重延迟导致彻底超时，全自动现场重发码，无需用户重启脚本
                    print("[-] 触发保护机制：上一个码已彻底超时。别慌！正在全自动为您重新发送新码...")
                    send_code_result = await client.send_code_request(phone)
                    phone_code_hash = send_code_result.phone_code_hash
                    print("[📢 系统提示] 新验证码已发出，请去接码平台刷新获取最新数字。")
                except SessionPasswordNeededError:
                    pwd = input("[-] 检测到两步验证，请输入该账号的二级密码: ")
                    await client.sign_in(password=pwd)
                    break

        print("\n" + "="*40)
        print("[OK] 恭喜！老账号安全通道已成功生成并挂载就绪！")
        print("-> 脚本已常驻后台，正在为您 24 小时实时监听该号收到的验证码...")
        print("="*40 + "\n")
        
        # 持续连接，永不断连
        await client.run_until_disconnected()
        
    except Exception as e:
        print(f"\n[-] 握手失败，原因: {e}")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[-] 脚本已安全退出。")
