import os
import sys
import asyncio
from telethon import TelegramClient, events

# === 🌟 您的真实 API 信息 🌟 ===
API_ID = 30565629          
API_HASH = "26e20159e146c83b4a58cd62a1ef839e"  
# ===============================================

sys.stdout.reconfigure(line_buffering=True)
SESSION_NAME = "my_backup_session"

# 自动盲猜并适配您的代理网络
os.environ["all_proxy"] = "socks5://127.0.0.1:7890"

# 初始化客户端
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

# 精准监听官方系统验证码消息
@client.on(events.NewMessage(incoming=True))
async def handler(event):
    if event.is_private:
        sender = await event.get_sender()
        if sender and getattr(sender, 'verified', False) or "telegram" in str(sender).lower():
            text = event.text or ""
            if "code" in text.lower() or "验证码" in text:
                print("\n" + "="*30)
                print("🔥 【重要提示】收到新设备登录验证码！")
                print(text)
                print("="*30 + "\n")

async def main():
    print("👉 正在建立安全网络握手...")
    try:
        # 启动官方标准的登录验证流程
        await client.start()
        print("\n[✔️] 成功连接并挂载就绪！")
        print("👉 脚本已安全常驻后台，正在监听验证码中...\n")
        await client.run_until_disconnected()
    except Exception as e:
        print(f"\n❌ 运行出错，错误原因：{e}")

# === ✨ 此处已修正：修复了 NameError 语法错误 ✨ ===
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 脚本已安全退出。")
