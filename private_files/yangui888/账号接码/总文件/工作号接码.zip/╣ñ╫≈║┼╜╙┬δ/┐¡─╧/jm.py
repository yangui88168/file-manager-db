import os
import sys
import asyncio
from telethon import TelegramClient, events

# === 您的真实 API 信息 ===
API_ID = 38764374
API_HASH = "42058f5e7bd7d0cdeef061d80ce30c00"  
# ===============================================

sys.stdout.reconfigure(line_buffering=True)
SESSION_NAME = "my_backup_session"

# 【终极修改】彻底移除固定端口，强行让脚本直接读取 Windows 系统当前的全局代理
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

# 精准监听官方系统验证码消息
@client.on(events.NewMessage(incoming=True))
async def handler(event):
    if event.is_private:
        sender = await event.get_sender()
        if (sender and getattr(sender, 'verified', False)) or "telegram" in str(sender).lower():
            text = event.text or ""
            if "code" in text.lower() or "验证码" in text:
                print("\n" + "*" * 30)
                print("[重要提示] 收到新设备登录验证码！")
                print(text)
                print("*" * 30 + "\n")

async def main():
    print("-> 正在通过系统全局环境建立 Telegram 安全网络握手...")
    try:
        # 启动官方标准的登录验证流程
        await client.start()
        print("\n[OK] 成功连接并挂载就绪！")
        print("-> 脚本已安全常驻后台，正在监听验证码中...\n")
        await client.run_until_disconnected()
    except Exception as e:
        print(f"\n[-] 连接失败，错误原因：{e}")
        print("[-] 解决办法：请鼠标右键点击电脑右下角的 v2rayN 图标，将【系统代理】切换为【自动配置系统代理】后再运行！\n")

if __name__ == "__main__":
    try:
        if os.path.exists(f"{SESSION_NAME}.session"):
            try: os.remove(f"{SESSION_NAME}.session")
            except: pass
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[-] 脚本已安全退出。")
